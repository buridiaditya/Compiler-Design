
void main(){
    int a = 9,b = 8, c = 11;
    c = (a<<2) + (a >>2);
    c = a+b*c;
    c = a+(b*c);
    int d = 0;
    a -= b;
    c += d;
    d *= d;
    int e = 27;
    e /= a;
    e %= e;
    return;	
}
