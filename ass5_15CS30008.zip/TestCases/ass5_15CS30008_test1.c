
int printInt(int a);

int main(){
	int i = 0;
	int a = 10,c=10;
	int d = 1;
	for( i = 0; i < a; i++){
		d = printInt(i);
		d = c+d;
	}
	return 1;
}
