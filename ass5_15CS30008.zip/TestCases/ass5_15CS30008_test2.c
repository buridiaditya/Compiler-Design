int printInt(int a);
int add(int a,int b){
	return a+b;
}

int main(){
	int a = 9,b = 18;
	int c = add(a,b);
	a = printInt(a);
	int d;
	return d;
}
