#ifndef _MYL_H
#define _MYL_H
#define ERR 1
#define OK 0
int printStr(char *a);
int printInt(int a);
int readInt(int *a);
int readFlt(float *a);
int printFlt(float a);
#endif
